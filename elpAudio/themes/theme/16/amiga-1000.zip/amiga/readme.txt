Skin made by Kent Stahre "Alias Artech" 22/6 98.  Updated 15/10 98

enjoy my skin for Amp.
-------------------------------------
My homepage:  http://www.one.se/~kent
My E-Mail:    kent@one.se
My UIN:11652408
